import React, { useState } from 'react'
import { useComplaintClosedMutation, useGetbranchByMobileQuery, useGetComplaintsQuery } from '../services/complaintApi'
import { useGetbranchesQuery } from '../services/schoolApi';

function Callcenter() {
    var {isLoading,data} = useGetComplaintsQuery();
    console.log(isLoading,data);

    var [closedFn] = useComplaintClosedMutation();
    var { isLoading:bLoading, data:bdata } = useGetbranchesQuery();
    var [search,setSearch] = useState('');
    var [selbranch,setSelBranch] = useState([]);
    var [selstatus,setSelStatus] = useState('all');
    // var {isLoading : bloading ,data : mdata} = useGetbranchByMobileQuery(search);
    function comclosed(id){
        closedFn(id).then((res)=>{
            console.log(res);
        })
    }

    function Mobilefil(m){
        return String(m.mobile).includes(search);
    }

    var MobileFiltered = data?.filter(Mobilefil).filter((complaint)=>{
        if(selbranch.length === 0){
            return true;
        }
        else{
            return selbranch.includes(complaint.branch);
        }
    })

    var StatusFiltered = MobileFiltered?.filter((complaint)=>{
        if(selstatus === 'all'){
            return true;
        }
        else{
            return complaint.status.some((status)=>{ return status.code === selstatus })
        }
    })

    function handleBranch(e){
        var { value, checked } = e.target;
        var checkupdates;
        if(checked){
            checkupdates = [...selbranch,value];
        }
        else{
            checkupdates = selbranch.filter((b)=>{ return b !== value })
        }
        setSelBranch(checkupdates);
    }

    function handleStatus(e){
        setSelStatus(e.target.value);
    }
  return (
    <div>
      <h3 className='text-center my-4'>COMPLAINTS</h3>
      <input type="text" className='form-control p-2 mb-3 w-25' placeholder='Mobile Number'
      value={search} onChange={(e)=>{ setSearch(e.target.value)}} style={{marginLeft:'580px'}}/>
        <div className='d-flex p-3'>
            <div className='w-25'>
                 {
                     !bLoading && bdata?.map((b,i)=>{
                        return (
                            <div key={i}>
                                <input type="checkbox" value={b.branchname} className='form-check-input'
                                checked={selbranch.includes(b.branchname)}  onChange={handleBranch}/>
                                <label htmlFor={b.branchname} className='form-check-label ms-3 mb-2'>
                                    {b.branchname}
                                </label>
                            </div>
                        )
                     })
                 }
            </div>
           <div className='w-75'>
               <div className='mb-4'>
                      <div>
                        {/* <h5>Filter by Status:</h5> */}
                        <label>
                            <input type="radio" value='all' checked={selstatus === 'all'} onChange={handleStatus} className='ms-3' /> All
                        </label>
                        <label>
                            <input type="radio" value='assigned' checked={selstatus === 'assigned'} onChange={handleStatus}className='ms-3' /> Assigned
                        </label>
                        <label>
                            <input type="radio" value='accepted' checked={selstatus === 'accepted'} onChange={handleStatus} className='ms-3' /> Pending
                        </label>
                        <label>
                            <input type="radio" value='solved' checked={selstatus === 'solved'} onChange={handleStatus} className='ms-3' /> Solved
                        </label>
                        <label>
                            <input type="radio" value='closed' checked={selstatus === 'closed'} onChange={handleStatus} className='ms-3' /> Closed
                        </label>
                      </div> 
               </div>
               <div>
                 <table className='table table-bordered text-center container shadow-sm'>
                     <thead>
                         <tr>
                             <th>Student Name</th>
                             <th>Mobile</th>
                             <th>Branch</th>
                             <th>Complaint</th>
                             <th>Status</th>
                         </tr>   
                     </thead>
                     <tbody>
                        {
                            !isLoading && StatusFiltered?.map((d,i)=>{
                                return (
                                    <tr key={i}>
                                        <td>{d.studentname}</td>
                                        <td>{d.mobile}</td>
                                        <td>{d.branch}</td>
                                        <td>{d.complaint}</td>
                                        <td>
                                            {
                                                [...d.status].sort((a,b)=>{ return a.timestamp < b.timestamp ? 1 : -1})[0].code === 'solved'
                                                ? (
                                                    <button className='btn btn-success' onClick={()=>{comclosed(d._id)}}>Close</button>
                                                ) : [...d.status].sort((a,b)=>{return a.timestamp < b.timestamp ? 1 : -1})[0].code !== 'closed' 
                                                ? ( <b>Pending</b> ) : null
                                            }
                                            { 
                                                [...d.status].sort((a,b)=>{ return a.timestamp < b.timestamp ? 1 : -1})[0].code === 'closed'
                                                && <> <b>Complaint Closed</b> </>
                                            }
                                        </td>
                                    </tr>
                                )
                            })
                        }
                     </tbody>
                 </table>
               </div>
           </div> 
        </div>
      
    </div>
  )
}

export default Callcenter

